from src.Test.conftest import *

from Config import config
config.broadcast_port = 0
